/* fonts */
export const FontFamily = {
  robotoMonoBold: "RobotoMono-Bold",
};
/* font sizes */
export const FontSize = {
  size_5xl: 24,
};
/* Colors */
export const Color = {
  colorWhite: "#fff",
};
