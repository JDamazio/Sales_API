import * as React from "react";
import {
  View,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  Image,
} from "react-native";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const Login = () => {
  return (
    <View style={styles.login}>
      <View style={styles.formLogin}>
        <Pressable
          style={[styles.buttonLogin1, styles.loginLayout]}
          loginButton="LoginButton"
        >
          <View style={[styles.login1, styles.login1Position]} />
          <Text style={[styles.logIn1, styles.logo1Typo]}>Log In</Text>
        </Pressable>
        <TextInput
          style={[styles.passwordInput, styles.inputLayout]}
          placeholder="Senha"
          placeholderTextColor="#000"
        />
        <TextInput
          style={[styles.usernameInput, styles.inputLayout]}
          placeholder="Usuário"
          placeholderTextColor="#000"
        />
      </View>
      <View style={[styles.logo, styles.logoLayout]}>
        <Image
          style={[styles.logoChild, styles.logoLayout]}
          resizeMode="cover"
          source={require("../assets/ellipse-1.png")}
        />
        <Text style={[styles.logo1, styles.logoLayout]}>LOGO</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  loginLayout: {
    height: 70,
    width: 228,
    position: "absolute",
  },
  login1Position: {
    left: 0,
    top: 0,
  },
  logo1Typo: {
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.robotoMonoBold,
    fontWeight: "700",
    letterSpacing: 1.2,
    fontSize: FontSize.size_5xl,
    left: 0,
    top: 0,
  },
  inputLayout: {
    height: 93,
    left: 0,
    width: 302,
    position: "absolute",
  },
  logoLayout: {
    height: 169,
    width: 169,
    position: "absolute",
  },
  login1: {
    borderRadius: 15,
    backgroundColor: "#317ad9",
    height: 70,
    width: 228,
    position: "absolute",
  },
  logIn1: {
    height: 70,
    width: 228,
    position: "absolute",
  },
  buttonLogin1: {
    top: 218,
    left: 37,
  },
  passwordInput: {
    top: 103,
  },
  usernameInput: {
    top: 0,
    height: 93,
  },
  formLogin: {
    top: 278,
    left: 44,
    height: 288,
    width: 302,
    position: "absolute",
  },
  logoChild: {
    left: 0,
    top: 0,
  },
  logo1: {
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    color: Color.colorWhite,
    fontFamily: FontFamily.robotoMonoBold,
    fontWeight: "700",
    letterSpacing: 1.2,
    fontSize: FontSize.size_5xl,
    left: 0,
    top: 0,
  },
  logo: {
    top: 50,
    left: 110,
  },
  login: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 844,
    overflow: "hidden",
  },
});

export default Login;
